import { useEffect, useState } from "react";
import Banner from "../components/banner/Banner";
import GameCard from "../components/gamecard/GameCard";
import { useNavigate } from "react-router-dom";

export default function Home() {
  const [games, setGames] = useState([]);
  const navigate = useNavigate();

  const banners = [
    "/images/baner1.png",
    "/images/baner2.png",
    "/images/banner3.jpg"
  ];

  useEffect(() => {
    fetch("/api/games")
      .then(res => res.json())
      .then(data => setGames(data))
      .catch(err => console.error(err));
  }, []);

  const pilihGame = (game) => {
    navigate(`/topup/${game.id}`);
  };

  return (
    <div className="max-w-[1400px] mx-auto px-4 pt-10">
      <Banner banners={banners} />

      <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
        {games.map(game => (
          <GameCard
            key={game.id}
            game={game}
            onClick={pilihGame}
          />
        ))}
      </div>
    </div>
  );
}
