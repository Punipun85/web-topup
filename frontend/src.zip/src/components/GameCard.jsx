export default function GameCard({ game, onClick }) {
  return (
    <div
      onClick={() => onClick(game)}
      className="bg-[#1c1c24] p-4 rounded-2xl cursor-pointer hover:scale-105 transition"
    >
      <img src={game.image} className="rounded-xl mb-2" />
      <p className="text-center text-xs font-bold">{game.name}</p>
    </div>
  );
}
